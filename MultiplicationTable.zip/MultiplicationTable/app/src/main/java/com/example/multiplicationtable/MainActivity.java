package com.example.multiplicationtable;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textview;
    private Button button;
    private EditText edittext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittext = findViewById(R.id.editTextNumber);
        button = findViewById(R.id.button);
        textview = findViewById(R.id.textView2);
        StringBuffer buffer = new StringBuffer();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int edit = Integer.parseInt(edittext.getText().toString());
                int i=1;
                while(i<11){
                    buffer.append(edit+" X "+i+" = "+ edit*i+"\n");
                    i=i+1;
                }
                textview.setText(buffer);
            }
        });

    }
}